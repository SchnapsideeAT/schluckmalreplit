import { InteractiveTutorial } from "@/components/InteractiveTutorial";

const InteractiveTutorialPage = () => {
  return <InteractiveTutorial />;
};

export default InteractiveTutorialPage;
